jailhouse cell create imx8mp-uart-wheatfox.cell
jailhouse cell load uart-wheatfox uart-wheatfox.bin
jailhouse cell start uart-wheatfox