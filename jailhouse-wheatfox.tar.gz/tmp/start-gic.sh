./tools/jailhouse cell create imx8mp-gic-demo.cell
./tools/jailhouse cell load gic-demo gic-demo.bin
./tools/jailhouse cell start gic-demo