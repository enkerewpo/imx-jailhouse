jailhouse cell create imx8mp-gic-demo.cell
jailhouse cell load gic-demo gic-demo.bin
jailhouse cell start gic-demo