./tools/jailhouse cell create imx8mp-uart-wheatfox.cell
./tools/jailhouse cell load uart-wheatfox uart-wheatfox.bin
./tools/jailhouse cell start uart-wheatfox